package main.java.coreutils;

public class Global 
{
	public static final String BROWSER_FIREFOX = "";
	public static final String BROWSER_IEXPLORER = "";
	public static final String BROWSER_CHROME = "Chrome";
	public static final String BROWSER_SAFARI = "";
	
	public static String gCurrentLocale = "";
	public static String gErrMsg = "";
	public static String sCurrentBrowserName = "";
	public static String sAppURL = "";
	
	public static final String Chrome_Driver_Path = "C:\\Automation\\Drivers\\chromedriver.exe";
}
